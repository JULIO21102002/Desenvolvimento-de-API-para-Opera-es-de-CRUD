const express = require('express');
const Produto = require('../models/Produto');
const router = express.Router();

// Criar um novo produto
router.post('/', async (req, res) => {
    const produto = new Produto(req.body);
    try {
        await produto.save();
        res.status(201).send(produto);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Listar todos os produtos
router.get('/', async (req, res) => {
    try {
        const produtos = await Produto.find();
        res.send(produtos);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Obter um produto por ID
router.get('/:id', async (req, res) => {
    try {
        const produto = await Produto.findById(req.params.id);
        if (!produto) return res.status(404).send();
        res.send(produto);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Atualizar um produto
router.patch('/:id', async (req, res) => {
    try {
        const produto = await Produto.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!produto) return res.status(404).send();
        res.send(produto);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Deletar um produto
router.delete('/:id', async (req, res) => {
    try {
        const produto = await Produto.findByIdAndDelete(req.params.id);
        if (!produto) return res.status(404).send();
        res.send(produto);
    } catch (error) {
        res.status(500).send(error);
    }
});

module.exports = router;
